<?php

include 'notation.php';
include 'getAverageNote.php';

echo note();
echo getAverageNote();
?>